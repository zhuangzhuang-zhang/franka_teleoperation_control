#include <iostream>
#include <servo_control_class/servo_control_two.h>

int main(int argc,char **argv)
{
    ros::init(argc, argv, "servo_control_node");

    franka_teleoperation teleop;

    ros::AsyncSpinner spinner(4);
    spinner.start();

    teleop.halt();
	ros::waitForShutdown();

	return 0;
}
