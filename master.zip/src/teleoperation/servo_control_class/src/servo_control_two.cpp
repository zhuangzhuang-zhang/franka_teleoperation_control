#include <servo_control_class/servo_control_two.h>

franka_teleoperation::franka_teleoperation(){

    nh_.getParam("/urdf_path", urdf_file);
    nh_.getParam("/chain_start1", chain_start1);
    nh_.getParam("/chain_end1", chain_end1);
    nh_.getParam("/chain_start2", chain_start2);
    nh_.getParam("/chain_end2", chain_end2);

    nh_.getParam("/sim", sim);
    nh_.getParam("/low_pass_fliter",filter);
    nh_.getParam("/rcm1_x", rcm_point1[0]);
    nh_.getParam("/rcm1_y", rcm_point1[1]);
    nh_.getParam("/rcm1_z", rcm_point1[2]);
    nh_.getParam("/rcm2_x", rcm_point2[0]);
    nh_.getParam("/rcm2_y", rcm_point2[1]);
    nh_.getParam("/rcm2_z", rcm_point2[2]);
    nh_.getParam("/keyboard",keyBoard);
    nh_.getParam("/footswitch",footswitch);
    nh_.getParam("/camera_in_base1_x", camera_in_base1[0]);
    nh_.getParam("/camera_in_base1_y", camera_in_base1[1]);
    nh_.getParam("/camera_in_base1_z", camera_in_base1[2]);
    nh_.getParam("/camera_in_base1_qx", camera_in_base1[3]);
    nh_.getParam("/camera_in_base1_qy", camera_in_base1[4]);
    nh_.getParam("/camera_in_base1_qz", camera_in_base1[5]);
    nh_.getParam("/camera_in_base1_qw", camera_in_base1[6]);
    nh_.getParam("/camera_in_base2_x", camera_in_base2[0]);
    nh_.getParam("/camera_in_base2_y", camera_in_base2[1]);
    nh_.getParam("/camera_in_base2_z", camera_in_base2[2]);
    nh_.getParam("/camera_in_base2_qx", camera_in_base2[3]);
    nh_.getParam("/camera_in_base2_qy", camera_in_base2[4]);
    nh_.getParam("/camera_in_base2_qz", camera_in_base2[5]);
    nh_.getParam("/camera_in_base2_qw", camera_in_base2[6]);
    nh_.getParam("/eye_hand_cooperation", eye_hand_cooperation);
    nh_.getParam("/rcm", rcm_enable);


    if(eye_hand_cooperation){
        Eigen::Quaterniond cam_in_base1_q(camera_in_base1[6],camera_in_base1[3],camera_in_base1[4],camera_in_base1[5]);
        Eigen::Quaterniond cam_in_base2_q(camera_in_base2[6],camera_in_base2[3],camera_in_base2[4],camera_in_base2[5]);
        Eigen::Matrix<double,3,3> cam_in_base1_r = cam_in_base1_q.toRotationMatrix();
        Eigen::Matrix<double,3,3> cam_in_base2_r = cam_in_base2_q.toRotationMatrix();
        for(unsigned int i=0;i<3;i++){
            for(unsigned int j=0;j<3;j++){
                camera_in_base1_matrix(i,j) = cam_in_base1_r(i,j);
                camera_in_base2_matrix(i,j) = cam_in_base2_r(i,j);
            }
        }
        for(unsigned int i=0;i<3;i++){
            camera_in_base1_matrix(i,3) = camera_in_base1[i];
            camera_in_base2_matrix(i,3) = camera_in_base2[i];
        }
        for(unsigned int i=0;i<3;i++){
            camera_in_base1_matrix(3,i) = 0;
            camera_in_base2_matrix(3,i) = 0;
        }
        camera_in_base1_matrix(3,3) = 1;
        camera_in_base2_matrix(3,3) = 1;
    }else{
        for(unsigned int i=0;i<4;i++)
            for(unsigned int j=0;j<4;j++){
                camera_in_base1_matrix(i,j) = 0;
                camera_in_base2_matrix(i,j) = 0;
            }
        camera_in_base1_matrix(0,0) = 1;
        camera_in_base1_matrix(1,1) = 1;
        camera_in_base1_matrix(2,2) = 1;
        camera_in_base1_matrix(3,3) = 1;
        camera_in_base2_matrix(0,0) = 1;
        camera_in_base2_matrix(1,1) = 1;
        camera_in_base2_matrix(2,2) = 1;
        camera_in_base2_matrix(3,3) = 1;
    }


    std::cout<<"urdf_file: "<<urdf_file<<std::endl;
    std::cout<<"chain_start1: "<<chain_start1<<std::endl;
    std::cout<<"chain_end1: "<<chain_end1<<std::endl;
    std::cout<<"chain_start2: "<<chain_start2<<std::endl;
    std::cout<<"chain_end2: "<<chain_end2<<std::endl;

    std::cout<<"sim: "<<sim<<std::endl;
    std::cout<<"fliter: "<<filter<<std::endl;
    std::cout<<"eye_hand_cooperation: "<<eye_hand_cooperation<<std::endl;
    std::cout<<"rcm: "<<rcm_enable<<std::endl;
    std::cout<<"keyBoard: "<<keyBoard<<std::endl;
    std::cout<<"footswitch: "<<footswitch<<std::endl;
    std::cout<<"rcm1: "<<rcm_point1[0]<<"   "<<rcm_point1[1]<<"   "<<rcm_point1[2]<<std::endl;
    std::cout<<"rcm2: "<<rcm_point2[0]<<"   "<<rcm_point2[1]<<"   "<<rcm_point2[2]<<std::endl;
    std::cout<<"camera_in_base1_matrix:"<<std::endl<<camera_in_base1_matrix<<std::endl;
    std::cout<<"camera_in_base2_matrix:"<<std::endl<<camera_in_base2_matrix<<std::endl;

    if(!sim)
        pub_franka_script = nh_.advertise<franka_msgs::servoj>("franka/servoj",10);
    else
        pub_sim_servoj = nh_.advertise<franka_msgs::servoj>("sim_franka_servoj", 10);

    sub_joint_position = nh_.subscribe("joint_states", 100, &franka_teleoperation::joint_position_callback, this);

    if(!filter)
        sub_touch_map = nh_.subscribe("omega_map", 100, &franka_teleoperation::touch_map_callback, this);
    else
        sub_touch_map = nh_.subscribe("omega_map_filter", 100, &franka_teleoperation::touch_map_callback, this);


    fk_thread_ = new std::thread(boost::bind(&franka_teleoperation::fk_func,this)); 
	keyboard_thread_ = new std::thread(boost::bind(&franka_teleoperation::keyboard_func,this));
    footswitch_thread_ = new std::thread(boost::bind(&franka_teleoperation::footswitch_func,this));   
	control_thread_ = new std::thread(boost::bind(&franka_teleoperation::control_func,this));
}

franka_teleoperation::~franka_teleoperation(){}

void franka_teleoperation::halt(){
    fk_thread_->join();
    keyboard_thread_->join();
    footswitch_thread_->join();
    control_thread_->join();
}

void franka_teleoperation::fk_func(){
    KDL::Tree my_tree;
    if (!kdl_parser::treeFromFile(urdf_file, my_tree)){
        ROS_ERROR("Failed to construct kdl tree");
        exit(-1);
    }

    KDL::Chain my_chain1;
    if(!my_tree.getChain(chain_start1, chain_end1, my_chain1)){
        ROS_ERROR("Failed to convert to chain1");
        exit(-1);
    }
    KDL::Chain my_chain2;
    if(!my_tree.getChain(chain_start2, chain_end2, my_chain2)){
        ROS_ERROR("Failed to convert to chain2");
        exit(-1);
    }

    KDL::ChainFkSolverPos_recursive fksolver1 = KDL::ChainFkSolverPos_recursive(my_chain1);
    nj1 = my_chain1.getNrOfJoints();
    if(nj1!=7){
        ROS_ERROR("nj1 error!");
        exit(-1);
    }
    KDL::JntArray jointpositions1 = KDL::JntArray(nj1);

    KDL::ChainFkSolverPos_recursive fksolver2 = KDL::ChainFkSolverPos_recursive(my_chain2);
    nj2 = my_chain2.getNrOfJoints();
    if(nj2!=7){
        ROS_ERROR("nj2 error!");
        exit(-1);
    }
    KDL::JntArray jointpositions2 = KDL::JntArray(nj2);

    ros::Rate loop_rate(100);
    while(ros::ok()){
        for(unsigned int i=0;i<nj1;i++){
          jointpositions1(i)=joint_positions1[i];
        }
        for(unsigned int i=0;i<nj2;i++){
          jointpositions2(i)=joint_positions2[i];
        }

        KDL::Frame cartpos1;
		KDL::Frame cartpos2;

        int kinematics_status1 = fksolver1.JntToCart(jointpositions1,cartpos1);
        if(kinematics_status1<0){
            ROS_ERROR("fk1 error!");
            exit(-1);
        }
        int kinematics_status2 = fksolver2.JntToCart(jointpositions2,cartpos2);
        if(kinematics_status2<0){
            ROS_ERROR("fk2 error!");
            exit(-1);
        }

        for(unsigned int i=0;i<3;i++)
            for(unsigned int j=0;j<3;j++){
                cur_ee1(i,j) = cartpos1.M(i,j);
            }
        cur_ee1(0,3) = cartpos1.p(0);cur_ee1(1,3) = cartpos1.p(1);cur_ee1(2,3) = cartpos1.p(2);
        cur_ee1(3,0) = 0;cur_ee1(3,1) = 0;cur_ee1(3,2) = 0;cur_ee1(3,3) = 1;

        slave1_current_pose = cur_ee1;

        for(unsigned int i=0;i<3;i++)
            for(unsigned int j=0;j<3;j++){
                cur_ee2(i,j) = cartpos2.M(i,j);
            }
        cur_ee2(0,3) = cartpos2.p(0);cur_ee2(1,3) = cartpos2.p(1);cur_ee2(2,3) = cartpos2.p(2);
        cur_ee2(3,0) = 0;cur_ee2(3,1) = 0;cur_ee2(3,2) = 0;cur_ee2(3,3) = 1;

        slave2_current_pose = cur_ee2;

        loop_rate.sleep();
    }
    std::cout<<"exit fk thread"<<std::endl;
}

void franka_teleoperation::keyboard_func(){
    int keys_fd;
    struct input_event t;
    keys_fd = open (keyBoard.c_str(), O_RDONLY);
    if (keys_fd <= 0){
            ROS_ERROR("can't open keyboard device!");
            exit(-1);
    }

    while (ros::ok()) {
        if (read(keys_fd, &t, sizeof (t)) == sizeof (t)){
            if (t.code == KEY_E){
                if(t.value==1){
                    master1_pos_zero[0] = master1_pos[0];
                    master1_pos_zero[1] = master1_pos[1];
                    master1_pos_zero[2] = master1_pos[2];
                    master1_rpy_zero[0] = master1_rpy[0];
                    master1_rpy_zero[1] = master1_rpy[1];
                    master1_rpy_zero[2] = master1_rpy[2];

                    slave1_zero = slave1_current_pose;
                    slave1_zero_in_cam = camera_in_base1_matrix.inverse() * slave1_current_pose;

                    tool_move = 0;

                    master2_pos_zero[0] = master2_pos[0];
                    master2_pos_zero[1] = master2_pos[1];
                    master2_pos_zero[2] = master2_pos[2];
                    master2_rpy_zero[0] = master2_rpy[0];
                    master2_rpy_zero[1] = master2_rpy[1];
                    master2_rpy_zero[2] = master2_rpy[2];

                    slave2_zero = slave2_current_pose;
                    slave2_zero_in_cam = camera_in_base2_matrix.inverse() * slave2_current_pose;

                    std::cout<<"master and slave init success"<<std::endl;
                }else if(t.value==2){
                    control_activate_ = true;
                    std::cout<<"activate controller"<<std::endl;
                }else if(t.value==0){
                    std::cout<<"deactivate controller"<<std::endl;
                    control_activate_ = false;
                }
            }else if(t.code == KEY_0 && t.value==1){
                control_activate_ = false;
                mode = 0;
                std::cout<<"***********************"<<std::endl;
                std::cout<<"position mode!"<<std::endl;
            }else if(t.code == KEY_1 && t.value==1){
                control_activate_ = false;
                mode = 1;
                std::cout<<"***********************"<<std::endl;
                std::cout<<"posture mode in base frame!"<<std::endl;
            }else if(t.code == KEY_2 && t.value==1){
                control_activate_ = false;
                mode = 2;
                std::cout<<"***********************"<<std::endl;
                std::cout<<"pose mode in base frame!"<<std::endl;
            }else if(t.code == KEY_3 && t.value==1){
                control_activate_ = false;
                mode = 3;
                std::cout<<"***********************"<<std::endl;
                std::cout<<"Ltool +"<<std::endl;
            }else if(t.code == KEY_4 && t.value==1){
                control_activate_ = false;
                mode = 4;
                std::cout<<"***********************"<<std::endl;
                std::cout<<"Ltool -"<<std::endl;
            }else if(t.code == KEY_5 && t.value==1){
                control_activate_ = false;
                mode = 5;
                std::cout<<"***********************"<<std::endl;
                std::cout<<"Rtool +"<<std::endl;
            }else if(t.code == KEY_6 && t.value==1){
				control_activate_ = false;
                mode = 6;
                std::cout<<"***********************"<<std::endl;
                std::cout<<"Rtool -"<<std::endl;
			}else if(t.code == KEY_W && t.value==1){
                control_activate_ = false;
                if(scale_p_x<(scale_p_max-scale_p_step)){
                    scale_p_x += scale_p_step;
                    scale_p_y += scale_p_step;
                    scale_p_z += scale_p_step;
                }else{
                    scale_p_x = scale_p_max;
                    scale_p_y = scale_p_max;
                    scale_p_z = scale_p_max;
                }
                std::cout<<"***********************"<<std::endl;
                std::cout<<"position_x_scale:  "<<scale_p_x<<"  position_y_scale: "<<scale_p_y
                         <<"  position_z_scale: "<<scale_p_z<<std::endl;
            }else if(t.code == KEY_S && t.value==1){
                control_activate_ = false;
                if(scale_p_x>(scale_p_min+scale_p_step)){
                    scale_p_x -= scale_p_step;
                    scale_p_y -= scale_p_step;
                    scale_p_z -= scale_p_step;
                }else{
                    scale_p_x = scale_p_min;
                    scale_p_y = scale_p_min;
                    scale_p_z = scale_p_min;
                }
                std::cout<<"***********************"<<std::endl;
                std::cout<<"position_x_scale:  "<<scale_p_x<<"  position_y_scale: "<<scale_p_y
                         <<"  position_z_scale: "<<scale_p_z<<std::endl;
            }else if(t.code == KEY_D && t.value==1){
                control_activate_ = false;
                if(scale_r_x<(scale_r_max-scale_r_step)){
                    scale_r_x += scale_r_step;
                    scale_r_y += scale_r_step;
                    scale_r_z += scale_r_step;
                }else{
                    scale_r_x = scale_r_max;
                    scale_r_y = scale_r_max;
                    scale_r_z = scale_r_max;
                }
                std::cout<<"***********************"<<std::endl;
                std::cout<<"posture_x_scale:  "<<scale_r_x<<"  posture_y_scale: "<<scale_r_y
                         <<"  posture_z_scale: "<<scale_r_z<<std::endl;
            }else if(t.code == KEY_A && t.value==1){
                control_activate_ = false;
                if(scale_r_x>(scale_r_min+scale_r_step)){
                    scale_r_x -= scale_r_step;
                    scale_r_y -= scale_r_step;
                    scale_r_z -= scale_r_step;
                }else{
                    scale_r_x = scale_r_min;
                    scale_r_y = scale_r_min;
                    scale_r_z = scale_r_min;
                }
                std::cout<<"***********************"<<std::endl;
                std::cout<<"posture_x_scale:  "<<scale_r_x<<"  posture_y_scale: "<<scale_r_y
                         <<"  posture_z_scale: "<<scale_r_z<<std::endl;
            }
        }
    }
    close (keys_fd);

    std::cout<<"exit keyboard thread"<<std::endl;
}

void franka_teleoperation::footswitch_func(){
    int keys_fd;
    struct input_event t;
    keys_fd = open (footswitch.c_str(), O_RDONLY);
    if (keys_fd <= 0){
            ROS_ERROR("can't open footswitch device!");
            exit(-1);
    }

    while (ros::ok()) {
        if (read(keys_fd, &t, sizeof (t)) == sizeof (t)){
            if (t.code == KEY_E){
                if(t.value==1){
                    master1_pos_zero[0] = master1_pos[0];
                    master1_pos_zero[1] = master1_pos[1];
                    master1_pos_zero[2] = master1_pos[2];
                    master1_rpy_zero[0] = master1_rpy[0];
                    master1_rpy_zero[1] = master1_rpy[1];
                    master1_rpy_zero[2] = master1_rpy[2];

                    slave1_zero = slave1_current_pose;
                    slave1_zero_in_cam = camera_in_base1_matrix.inverse() * slave1_current_pose;

                    tool_move = 0;

                    master2_pos_zero[0] = master2_pos[0];
                    master2_pos_zero[1] = master2_pos[1];
                    master2_pos_zero[2] = master2_pos[2];
                    master2_rpy_zero[0] = master2_rpy[0];
                    master2_rpy_zero[1] = master2_rpy[1];
                    master2_rpy_zero[2] = master2_rpy[2];

                    slave2_zero = slave2_current_pose;
                    slave2_zero_in_cam = camera_in_base2_matrix.inverse() * slave2_current_pose;

                    std::cout<<"master and slave init success"<<std::endl;
                }else if(t.value==2){
                    control_activate_ = true;
                    std::cout<<"activate controller"<<std::endl;
                }else if(t.value==0){
                    std::cout<<"deactivate controller"<<std::endl;
                    control_activate_ = false;
                }
            }
        }
    }
    close (keys_fd);

    std::cout<<"exit footswitch thread"<<std::endl;
}

void franka_teleoperation::control_func(){
    double timeout = 0.005;
    urdf_param = "/robot_description";
    double eps = 1e-5;
    TRAC_IK::TRAC_IK tracik_solver1(chain_start1, chain_end1, urdf_param, timeout, eps);
    KDL::Chain my_chain1;
    KDL::JntArray ll1, ul1;
    TRAC_IK::TRAC_IK tracik_solver2(chain_start2, chain_end2, urdf_param, timeout, eps);
    KDL::Chain my_chain2;
    KDL::JntArray ll2, ul2;

    bool valid1 = tracik_solver1.getKDLChain(my_chain1);
    if (!valid1) {
      ROS_ERROR("There was no valid KDL chain1 found");
      exit(-1);
    }

    valid1 = tracik_solver1.getKDLLimits(ll1,ul1);
    if (!valid1) {
      ROS_ERROR("There were no valid KDL joint1 limits found");
      exit(-1);
    }

    bool valid2 = tracik_solver2.getKDLChain(my_chain2);
    if (!valid2) {
      ROS_ERROR("There was no valid KDL chain2 found");
      exit(-1);
    }

    valid2 = tracik_solver1.getKDLLimits(ll2,ul2);
    if (!valid2) {
      ROS_ERROR("There were no valid KDL joint2 limits found");
      exit(-1);
    }

    KDL::JntArray jointpositions_to_solve1 = KDL::JntArray(nj1);
	KDL::JntArray jointpositions_to_solve2 = KDL::JntArray(nj2);

    for(int i=0;i<7;i++){
		jointpositions_to_solve1(i) = joint_positions1[i];
		jointpositions_to_solve2(i) = joint_positions2[i];
	}

    ros::Rate loop_rate(200);
    while(ros::ok()){
        if(control_activate_){
    		for(int i=0;i<7;i++){
				jointpositions_to_solve1(i) = joint_positions1[i];
				jointpositions_to_solve2(i) = joint_positions2[i];
			}


            Eigen::Matrix<double,4,4> slave1_desire_pose_in_cam = slave1_zero_in_cam;
            slave1_desire_pose_in_cam(0,3) = direction1_x * (master1_pos[0]-master1_pos_zero[0]) * scale_p_x + slave1_zero_in_cam(0,3);
            slave1_desire_pose_in_cam(1,3) = direction1_y * (master1_pos[1]-master1_pos_zero[1]) * scale_p_y + slave1_zero_in_cam(1,3);
            slave1_desire_pose_in_cam(2,3) = direction1_z * (master1_pos[2]-master1_pos_zero[2]) * scale_p_z + slave1_zero_in_cam(2,3);

            double master1_rpy_x_increase = direction1_rpy_r * scale_r_x*(master1_rpy[0]-master1_rpy_zero[0]);
            double master1_rpy_y_increase = direction1_rpy_p * scale_r_y*(master1_rpy[1]-master1_rpy_zero[1]);
            double master1_rpy_z_increase = direction1_rpy_y * scale_r_z*(master1_rpy[2]-master1_rpy_zero[2]);

            Eigen::Matrix<double,4,4> rotx,roty,rotz;
            rotx(0,0) = 1;rotx(0,1) = 0;                             rotx(0,2) = 0;                               rotx(0,3) = 0;
            rotx(1,0) = 0;rotx(1,1) = cos(master1_rpy_x_increase);   rotx(1,2) = -1*sin(master1_rpy_x_increase);  rotx(1,3) = 0;
            rotx(2,0) = 0;rotx(2,1) = sin(master1_rpy_x_increase);   rotx(2,2) = cos(master1_rpy_x_increase);     rotx(2,3) = 0;
            rotx(3,0) = 0;rotx(3,1) = 0;                             rotx(3,2) = 0;                               rotx(3,3) = 1;

            roty(0,0) = cos(master1_rpy_y_increase);     roty(0,1) = 0;  roty(0,2) = sin(master1_rpy_y_increase); roty(0,3) = 0;
            roty(1,0) = 0;                               roty(1,1) = 1;  roty(1,2) = 0;                           roty(1,3) = 0;
            roty(2,0) = -1*sin(master1_rpy_y_increase);  roty(2,1) = 0;  roty(2,2) = cos(master1_rpy_y_increase); roty(2,3) = 0;
            roty(3,0) = 0;                               roty(3,1) = 0;  roty(3,2) = 0;                           roty(3,3) = 1;

            rotz(0,0) = cos(master1_rpy_z_increase); rotz(0,1) = -1*sin(master1_rpy_z_increase);  rotz(0,2) = 0;  rotz(0,3) = 0;
            rotz(1,0) = sin(master1_rpy_z_increase); rotz(1,1) = cos(master1_rpy_z_increase);     rotz(1,2) = 0;  rotz(1,3) = 0;
            rotz(2,0) = 0;                           rotz(2,1) = 0;                               rotz(2,2) = 1;  rotz(2,3) = 0;
            rotz(3,0) = 0;                           rotz(3,1) = 0;                               rotz(3,2) = 0;  rotz(3,3) = 1;

            //rot in base frame
            Eigen::Matrix<double,4,4> slave1_desire_pose_fix_pos_in_cam;
            slave1_desire_pose_fix_pos_in_cam = rotz * roty * rotx * slave1_zero_in_cam;


            Eigen::Matrix<double,4,4> slave2_desire_pose_in_cam = slave2_zero_in_cam;
            slave2_desire_pose_in_cam(0,3) = direction2_x * (master2_pos[0]-master2_pos_zero[0]) * scale_p_x + slave2_zero_in_cam(0,3);
            slave2_desire_pose_in_cam(1,3) = direction2_y * (master2_pos[1]-master2_pos_zero[1]) * scale_p_y + slave2_zero_in_cam(1,3);
            slave2_desire_pose_in_cam(2,3) = direction2_z * (master2_pos[2]-master2_pos_zero[2]) * scale_p_z + slave2_zero_in_cam(2,3);

            double master2_rpy_x_increase = direction2_rpy_r * scale_r_x*(master2_rpy[0]-master2_rpy_zero[0]);
            double master2_rpy_y_increase = direction2_rpy_p * scale_r_y*(master2_rpy[1]-master2_rpy_zero[1]);
            double master2_rpy_z_increase = direction2_rpy_y * scale_r_z*(master2_rpy[2]-master2_rpy_zero[2]);

            Eigen::Matrix<double,4,4> rotx2,roty2,rotz2;
            rotx2(0,0) = 1;rotx2(0,1) = 0;                             rotx2(0,2) = 0;                               rotx2(0,3) = 0;
            rotx2(1,0) = 0;rotx2(1,1) = cos(master2_rpy_x_increase);   rotx2(1,2) = -1*sin(master2_rpy_x_increase);  rotx2(1,3) = 0;
            rotx2(2,0) = 0;rotx2(2,1) = sin(master2_rpy_x_increase);   rotx2(2,2) = cos(master2_rpy_x_increase);     rotx2(2,3) = 0;
            rotx2(3,0) = 0;rotx2(3,1) = 0;                             rotx2(3,2) = 0;                               rotx2(3,3) = 1;

            roty2(0,0) = cos(master2_rpy_y_increase);     roty2(0,1) = 0;  roty2(0,2) = sin(master2_rpy_y_increase); roty2(0,3) = 0;
            roty2(1,0) = 0;                               roty2(1,1) = 1;  roty2(1,2) = 0;                           roty2(1,3) = 0;
            roty2(2,0) = -1*sin(master2_rpy_y_increase);  roty2(2,1) = 0;  roty2(2,2) = cos(master2_rpy_y_increase); roty2(2,3) = 0;
            roty2(3,0) = 0;                               roty2(3,1) = 0;  roty2(3,2) = 0;                           roty2(3,3) = 1;

            rotz2(0,0) = cos(master2_rpy_z_increase); rotz2(0,1) = -1*sin(master2_rpy_z_increase);  rotz2(0,2) = 0;  rotz2(0,3) = 0;
            rotz2(1,0) = sin(master2_rpy_z_increase); rotz2(1,1) = cos(master2_rpy_z_increase);     rotz2(1,2) = 0;  rotz2(1,3) = 0;
            rotz2(2,0) = 0;                           rotz2(2,1) = 0;                               rotz2(2,2) = 1;  rotz2(2,3) = 0;
            rotz2(3,0) = 0;                           rotz2(3,1) = 0;                               rotz2(3,2) = 0;  rotz2(3,3) = 1;

            //rot in base frame
            Eigen::Matrix<double,4,4> slave2_desire_pose_fix_pos_in_cam;
            slave2_desire_pose_fix_pos_in_cam = rotz2 * roty2 * rotx2 * slave2_zero_in_cam;


            Eigen::Matrix<double,4,4> slave1_desire_pose = camera_in_base1_matrix * slave1_desire_pose_in_cam;
            Eigen::Matrix<double,4,4> slave2_desire_pose = camera_in_base2_matrix * slave2_desire_pose_in_cam;
            Eigen::Matrix<double,4,4> slave1_desire_pose_fix_pos = camera_in_base1_matrix * slave1_desire_pose_fix_pos_in_cam;
            Eigen::Matrix<double,4,4> slave2_desire_pose_fix_pos = camera_in_base2_matrix * slave2_desire_pose_fix_pos_in_cam;


            int result1 = -1;
			int result2 = -1;
            if(mode == 0 && !rcm_enable){//position mode
                KDL::JntArray q_init1 = KDL::JntArray(nj1);
				KDL::JntArray q_init2 = KDL::JntArray(nj2);
                for(int i=0; i<nj1; i++){
                  q_init1(i)=joint_positions1[i];
                  q_init2(i)=joint_positions2[i];
                }

                KDL::Frame F_dest1;
                F_dest1.M(0,0) = slave1_desire_pose(0,0);
                F_dest1.M(0,1) = slave1_desire_pose(0,1);
                F_dest1.M(0,2) = slave1_desire_pose(0,2);

                F_dest1.M(1,0) = slave1_desire_pose(1,0);
                F_dest1.M(1,1) = slave1_desire_pose(1,1);
                F_dest1.M(1,2) = slave1_desire_pose(1,2);

                F_dest1.M(2,0) = slave1_desire_pose(2,0);
                F_dest1.M(2,1) = slave1_desire_pose(2,1);
                F_dest1.M(2,2) = slave1_desire_pose(2,2);

                F_dest1.p(0) = slave1_desire_pose(0,3);
                F_dest1.p(1) = slave1_desire_pose(1,3);
                F_dest1.p(2) = slave1_desire_pose(2,3);
                result1 = tracik_solver1.CartToJnt(q_init1,F_dest1,jointpositions_to_solve1);

                KDL::Frame F_dest2;
                F_dest2.M(0,0) = slave2_desire_pose(0,0);
                F_dest2.M(0,1) = slave2_desire_pose(0,1);
                F_dest2.M(0,2) = slave2_desire_pose(0,2);

                F_dest2.M(1,0) = slave2_desire_pose(1,0);
                F_dest2.M(1,1) = slave2_desire_pose(1,1);
                F_dest2.M(1,2) = slave2_desire_pose(1,2);

                F_dest2.M(2,0) = slave2_desire_pose(2,0);
                F_dest2.M(2,1) = slave2_desire_pose(2,1);
                F_dest2.M(2,2) = slave2_desire_pose(2,2);

                F_dest2.p(0) = slave2_desire_pose(0,3);
                F_dest2.p(1) = slave2_desire_pose(1,3);
                F_dest2.p(2) = slave2_desire_pose(2,3);
                result2 = tracik_solver2.CartToJnt(q_init2,F_dest2,jointpositions_to_solve2);
            }else if(mode == 1 && !rcm_enable){//rot in base frame
                KDL::JntArray q_init1 = KDL::JntArray(nj1);
				KDL::JntArray q_init2 = KDL::JntArray(nj2);
                for(int i=0; i<nj1; i++){
                  q_init1(i)=joint_positions1[i];
                  q_init2(i)=joint_positions2[i];
                }

                KDL::Frame F_dest1;
                F_dest1.M(0,0) = slave1_desire_pose_fix_pos(0,0);
                F_dest1.M(0,1) = slave1_desire_pose_fix_pos(0,1);
                F_dest1.M(0,2) = slave1_desire_pose_fix_pos(0,2);

                F_dest1.M(1,0) = slave1_desire_pose_fix_pos(1,0);
                F_dest1.M(1,1) = slave1_desire_pose_fix_pos(1,1);
                F_dest1.M(1,2) = slave1_desire_pose_fix_pos(1,2);

                F_dest1.M(2,0) = slave1_desire_pose_fix_pos(2,0);
                F_dest1.M(2,1) = slave1_desire_pose_fix_pos(2,1);
                F_dest1.M(2,2) = slave1_desire_pose_fix_pos(2,2);

                F_dest1.p(0) = slave1_zero(0,3);
                F_dest1.p(1) = slave1_zero(1,3);
                F_dest1.p(2) = slave1_zero(2,3);
                result1 = tracik_solver1.CartToJnt(q_init1,F_dest1,jointpositions_to_solve1);

                KDL::Frame F_dest2;
                F_dest2.M(0,0) = slave2_desire_pose_fix_pos(0,0);
                F_dest2.M(0,1) = slave2_desire_pose_fix_pos(0,1);
                F_dest2.M(0,2) = slave2_desire_pose_fix_pos(0,2);

                F_dest2.M(1,0) = slave2_desire_pose_fix_pos(1,0);
                F_dest2.M(1,1) = slave2_desire_pose_fix_pos(1,1);
                F_dest2.M(1,2) = slave2_desire_pose_fix_pos(1,2);

                F_dest2.M(2,0) = slave2_desire_pose_fix_pos(2,0);
                F_dest2.M(2,1) = slave2_desire_pose_fix_pos(2,1);
                F_dest2.M(2,2) = slave2_desire_pose_fix_pos(2,2);

                F_dest2.p(0) = slave2_zero(0,3);
                F_dest2.p(1) = slave2_zero(1,3);
                F_dest2.p(2) = slave2_zero(2,3);
                result2 = tracik_solver2.CartToJnt(q_init2,F_dest2,jointpositions_to_solve2);

            }else if(mode == 2 && !rcm_enable){//position mode + rot in base frame
                KDL::JntArray q_init1 = KDL::JntArray(nj1);
				KDL::JntArray q_init2 = KDL::JntArray(nj2);
                for(int i=0; i<nj1; i++){
                  q_init1(i)=joint_positions1[i];
                  q_init2(i)=joint_positions2[i];
                }

                KDL::Frame F_dest1;
                F_dest1.M(0,0) = slave1_desire_pose_fix_pos(0,0);
                F_dest1.M(0,1) = slave1_desire_pose_fix_pos(0,1);
                F_dest1.M(0,2) = slave1_desire_pose_fix_pos(0,2);

                F_dest1.M(1,0) = slave1_desire_pose_fix_pos(1,0);
                F_dest1.M(1,1) = slave1_desire_pose_fix_pos(1,1);
                F_dest1.M(1,2) = slave1_desire_pose_fix_pos(1,2);

                F_dest1.M(2,0) = slave1_desire_pose_fix_pos(2,0);
                F_dest1.M(2,1) = slave1_desire_pose_fix_pos(2,1);
                F_dest1.M(2,2) = slave1_desire_pose_fix_pos(2,2);

                F_dest1.p(0) = slave1_desire_pose(0,3);
                F_dest1.p(1) = slave1_desire_pose(1,3);
                F_dest1.p(2) = slave1_desire_pose(2,3);
                result1 = tracik_solver1.CartToJnt(q_init1,F_dest1,jointpositions_to_solve1);

                KDL::Frame F_dest2;
                F_dest2.M(0,0) = slave2_desire_pose_fix_pos(0,0);
                F_dest2.M(0,1) = slave2_desire_pose_fix_pos(0,1);
                F_dest2.M(0,2) = slave2_desire_pose_fix_pos(0,2);

                F_dest2.M(1,0) = slave2_desire_pose_fix_pos(1,0);
                F_dest2.M(1,1) = slave2_desire_pose_fix_pos(1,1);
                F_dest2.M(1,2) = slave2_desire_pose_fix_pos(1,2);

                F_dest2.M(2,0) = slave2_desire_pose_fix_pos(2,0);
                F_dest2.M(2,1) = slave2_desire_pose_fix_pos(2,1);
                F_dest2.M(2,2) = slave2_desire_pose_fix_pos(2,2);

                F_dest2.p(0) = slave2_desire_pose(0,3);
                F_dest2.p(1) = slave2_desire_pose(1,3);
                F_dest2.p(2) = slave2_desire_pose(2,3);
                result2 = tracik_solver2.CartToJnt(q_init2,F_dest2,jointpositions_to_solve2);

            }else if(mode == 3){//tool1 feed
                Eigen::Matrix<double,4,4> zero_to_desire;
                tool_move += tool_step;
                zero_to_desire(0,0) = 1;zero_to_desire(0,1) = 0;zero_to_desire(0,2) = 0;zero_to_desire(0,3) = 0;
                zero_to_desire(1,0) = 0;zero_to_desire(1,1) = 1;zero_to_desire(1,2) = 0;zero_to_desire(1,3) = 0;
                zero_to_desire(2,0) = 0;zero_to_desire(2,1) = 0;zero_to_desire(2,2) = 1;zero_to_desire(2,3) = tool_move;
                zero_to_desire(3,0) = 0;zero_to_desire(3,1) = 0;zero_to_desire(3,2) = 0;zero_to_desire(3,3) = 1;

                Eigen::Matrix<double,4,4> tool_desired = slave1_zero*zero_to_desire;
                KDL::JntArray q_init = KDL::JntArray(nj1);
                for(int i=0; i<nj1; i++){
                  q_init(i)=joint_positions1[i];
                }

                KDL::Frame F_dest;
                F_dest.M(0,0) = tool_desired(0,0);
                F_dest.M(0,1) = tool_desired(0,1);
                F_dest.M(0,2) = tool_desired(0,2);

                F_dest.M(1,0) = tool_desired(1,0);
                F_dest.M(1,1) = tool_desired(1,1);
                F_dest.M(1,2) = tool_desired(1,2);

                F_dest.M(2,0) = tool_desired(2,0);
                F_dest.M(2,1) = tool_desired(2,1);
                F_dest.M(2,2) = tool_desired(2,2);

                F_dest.p(0) = tool_desired(0,3);
                F_dest.p(1) = tool_desired(1,3);
                F_dest.p(2) = tool_desired(2,3);
                result1 = tracik_solver1.CartToJnt(q_init,F_dest,jointpositions_to_solve1);
            }else if(mode == 4){//tool1 back
                Eigen::Matrix<double,4,4> zero_to_desire;
                tool_move -= tool_step;
                zero_to_desire(0,0) = 1;zero_to_desire(0,1) = 0;zero_to_desire(0,2) = 0;zero_to_desire(0,3) = 0;
                zero_to_desire(1,0) = 0;zero_to_desire(1,1) = 1;zero_to_desire(1,2) = 0;zero_to_desire(1,3) = 0;
                zero_to_desire(2,0) = 0;zero_to_desire(2,1) = 0;zero_to_desire(2,2) = 1;zero_to_desire(2,3) = tool_move;
                zero_to_desire(3,0) = 0;zero_to_desire(3,1) = 0;zero_to_desire(3,2) = 0;zero_to_desire(3,3) = 1;

                Eigen::Matrix<double,4,4> tool_desired = slave1_zero*zero_to_desire;
                KDL::JntArray q_init = KDL::JntArray(nj1);
                for(int i=0; i<nj1; i++){
                  q_init(i)=joint_positions1[i];
                }

                KDL::Frame F_dest;
                F_dest.M(0,0) = tool_desired(0,0);
                F_dest.M(0,1) = tool_desired(0,1);
                F_dest.M(0,2) = tool_desired(0,2);

                F_dest.M(1,0) = tool_desired(1,0);
                F_dest.M(1,1) = tool_desired(1,1);
                F_dest.M(1,2) = tool_desired(1,2);

                F_dest.M(2,0) = tool_desired(2,0);
                F_dest.M(2,1) = tool_desired(2,1);
                F_dest.M(2,2) = tool_desired(2,2);

                F_dest.p(0) = tool_desired(0,3);
                F_dest.p(1) = tool_desired(1,3);
                F_dest.p(2) = tool_desired(2,3);
                result1 = tracik_solver1.CartToJnt(q_init,F_dest,jointpositions_to_solve1);
            }else if(mode == 5){
                Eigen::Matrix<double,4,4> zero_to_desire;
                tool_move += tool_step;
                zero_to_desire(0,0) = 1;zero_to_desire(0,1) = 0;zero_to_desire(0,2) = 0;zero_to_desire(0,3) = 0;
                zero_to_desire(1,0) = 0;zero_to_desire(1,1) = 1;zero_to_desire(1,2) = 0;zero_to_desire(1,3) = 0;
                zero_to_desire(2,0) = 0;zero_to_desire(2,1) = 0;zero_to_desire(2,2) = 1;zero_to_desire(2,3) = tool_move;
                zero_to_desire(3,0) = 0;zero_to_desire(3,1) = 0;zero_to_desire(3,2) = 0;zero_to_desire(3,3) = 1;

                Eigen::Matrix<double,4,4> tool_desired = slave2_zero*zero_to_desire;
                KDL::JntArray q_init = KDL::JntArray(nj2);
                for(int i=0; i<nj2; i++){
                  q_init(i)=joint_positions2[i];
                }

                KDL::Frame F_dest;
                F_dest.M(0,0) = tool_desired(0,0);
                F_dest.M(0,1) = tool_desired(0,1);
                F_dest.M(0,2) = tool_desired(0,2);

                F_dest.M(1,0) = tool_desired(1,0);
                F_dest.M(1,1) = tool_desired(1,1);
                F_dest.M(1,2) = tool_desired(1,2);

                F_dest.M(2,0) = tool_desired(2,0);
                F_dest.M(2,1) = tool_desired(2,1);
                F_dest.M(2,2) = tool_desired(2,2);

                F_dest.p(0) = tool_desired(0,3);
                F_dest.p(1) = tool_desired(1,3);
                F_dest.p(2) = tool_desired(2,3);
                result2 = tracik_solver2.CartToJnt(q_init,F_dest,jointpositions_to_solve2);
            }else if(mode == 6){
                Eigen::Matrix<double,4,4> zero_to_desire;
                tool_move -= tool_step;
                zero_to_desire(0,0) = 1;zero_to_desire(0,1) = 0;zero_to_desire(0,2) = 0;zero_to_desire(0,3) = 0;
                zero_to_desire(1,0) = 0;zero_to_desire(1,1) = 1;zero_to_desire(1,2) = 0;zero_to_desire(1,3) = 0;
                zero_to_desire(2,0) = 0;zero_to_desire(2,1) = 0;zero_to_desire(2,2) = 1;zero_to_desire(2,3) = tool_move;
                zero_to_desire(3,0) = 0;zero_to_desire(3,1) = 0;zero_to_desire(3,2) = 0;zero_to_desire(3,3) = 1;

                Eigen::Matrix<double,4,4> tool_desired = slave2_zero*zero_to_desire;
                KDL::JntArray q_init = KDL::JntArray(nj2);
                for(int i=0; i<nj2; i++){
                  q_init(i)=joint_positions2[i];
                }

                KDL::Frame F_dest;
                F_dest.M(0,0) = tool_desired(0,0);
                F_dest.M(0,1) = tool_desired(0,1);
                F_dest.M(0,2) = tool_desired(0,2);

                F_dest.M(1,0) = tool_desired(1,0);
                F_dest.M(1,1) = tool_desired(1,1);
                F_dest.M(1,2) = tool_desired(1,2);

                F_dest.M(2,0) = tool_desired(2,0);
                F_dest.M(2,1) = tool_desired(2,1);
                F_dest.M(2,2) = tool_desired(2,2);

                F_dest.p(0) = tool_desired(0,3);
                F_dest.p(1) = tool_desired(1,3);
                F_dest.p(2) = tool_desired(2,3);
                result2 = tracik_solver2.CartToJnt(q_init,F_dest,jointpositions_to_solve2);
            }else if(mode == 0 && rcm_enable){//RCM
                KDL::JntArray q_init1 = KDL::JntArray(nj1);
				KDL::JntArray q_init2 = KDL::JntArray(nj2);
                for(int i=0; i<nj1; i++){
                  q_init1(i)=joint_positions1[i];
                  q_init2(i)=joint_positions2[i];
                }

                KDL::Frame F_dest1;

                Eigen::Matrix<double,3,1> desired_x_orientation1;
                Eigen::Matrix<double,3,1> desired_y_orientation1;
                Eigen::Matrix<double,3,1> desired_z_orientation1;
                desired_z_orientation1(0,0) = slave1_desire_pose(0,3) - rcm_point1[0];
                desired_z_orientation1(1,0) = slave1_desire_pose(1,3) - rcm_point1[1];
                desired_z_orientation1(2,0) = slave1_desire_pose(2,3) - rcm_point1[2];

                double temp = sqrt(desired_z_orientation1(0,0)*desired_z_orientation1(0,0)
                                   +desired_z_orientation1(1,0)*desired_z_orientation1(1,0)
                                   +desired_z_orientation1(2,0)*desired_z_orientation1(2,0));
                desired_z_orientation1(0,0) = desired_z_orientation1(0,0) / temp;
                desired_z_orientation1(1,0) = desired_z_orientation1(1,0) / temp;
                desired_z_orientation1(2,0) = desired_z_orientation1(2,0) / temp;

                Eigen::Matrix<double,3,1> slave1_zero_x_orientation,slave1_zero_y_orientation,slave1_zero_z_orientation;
                slave1_zero_x_orientation(0,0) = slave1_zero(0,0);
                slave1_zero_x_orientation(1,0) = slave1_zero(1,0);
                slave1_zero_x_orientation(2,0) = slave1_zero(2,0);

                slave1_zero_y_orientation(0,0) = slave1_zero(0,1);
                slave1_zero_y_orientation(1,0) = slave1_zero(1,1);
                slave1_zero_y_orientation(2,0) = slave1_zero(2,1);

                slave1_zero_z_orientation(0,0) = slave1_zero(0,2);
                slave1_zero_z_orientation(1,0) = slave1_zero(1,2);
                slave1_zero_z_orientation(2,0) = slave1_zero(2,2);

                Eigen::Matrix<double,3,1> rotation_axis1 = slave1_zero_z_orientation.cross(desired_z_orientation1);
                temp = sqrt(rotation_axis1(0,0)*rotation_axis1(0,0)
                           +rotation_axis1(1,0)*rotation_axis1(1,0)
                           +rotation_axis1(2,0)*rotation_axis1(2,0));
                rotation_axis1(0,0) = rotation_axis1(0,0) / temp;
                rotation_axis1(1,0) = rotation_axis1(1,0) / temp;
                rotation_axis1(2,0) = rotation_axis1(2,0) / temp;
                double rotation_angle1 = acos(slave1_zero_z_orientation.dot(desired_z_orientation1));

                Eigen::AngleAxisd V1(rotation_angle1, Eigen::Vector3d(rotation_axis1(0,0),rotation_axis1(1,0),rotation_axis1(2,0)));
                Eigen::Matrix<double,3,3> rotation_matrix1 = V1.toRotationMatrix();

                desired_y_orientation1 = rotation_matrix1 * slave1_zero_y_orientation;
                desired_x_orientation1 = rotation_matrix1 * slave1_zero_x_orientation;

                F_dest1.M(0,0) = desired_x_orientation1(0,0);
                F_dest1.M(0,1) = desired_y_orientation1(0,0);
                F_dest1.M(0,2) = desired_z_orientation1(0,0);

                F_dest1.M(1,0) = desired_x_orientation1(1,0);
                F_dest1.M(1,1) = desired_y_orientation1(1,0);
                F_dest1.M(1,2) = desired_z_orientation1(1,0);

                F_dest1.M(2,0) = desired_x_orientation1(2,0);
                F_dest1.M(2,1) = desired_y_orientation1(2,0);
                F_dest1.M(2,2) = desired_z_orientation1(2,0);

                F_dest1.p(0) = slave1_desire_pose(0,3);
                F_dest1.p(1) = slave1_desire_pose(1,3);
                F_dest1.p(2) = slave1_desire_pose(2,3);
                result1 = tracik_solver1.CartToJnt(q_init1,F_dest1,jointpositions_to_solve1);


                KDL::Frame F_dest2;
				std::cout<<"slave2_desire_pose: "<<slave2_desire_pose(0,3)<<"  "<<slave2_desire_pose(1,3)<<"   "<<slave2_desire_pose(2,3)<<std::endl;
                Eigen::Matrix<double,3,1> desired_x_orientation2;
                Eigen::Matrix<double,3,1> desired_y_orientation2;
                Eigen::Matrix<double,3,1> desired_z_orientation2;
                desired_z_orientation2(0,0) = slave2_desire_pose(0,3) - rcm_point2[0];
                desired_z_orientation2(1,0) = slave2_desire_pose(1,3) - rcm_point2[1];
                desired_z_orientation2(2,0) = slave2_desire_pose(2,3) - rcm_point2[2];

                temp = sqrt(desired_z_orientation2(0,0)*desired_z_orientation2(0,0)
                                   +desired_z_orientation2(1,0)*desired_z_orientation2(1,0)
                                   +desired_z_orientation2(2,0)*desired_z_orientation2(2,0));
                desired_z_orientation2(0,0) = desired_z_orientation2(0,0) / temp;
                desired_z_orientation2(1,0) = desired_z_orientation2(1,0) / temp;
                desired_z_orientation2(2,0) = desired_z_orientation2(2,0) / temp;

                Eigen::Matrix<double,3,1> slave2_zero_x_orientation,slave2_zero_y_orientation,slave2_zero_z_orientation;
                slave2_zero_x_orientation(0,0) = slave2_zero(0,0);
                slave2_zero_x_orientation(1,0) = slave2_zero(1,0);
                slave2_zero_x_orientation(2,0) = slave2_zero(2,0);

                slave2_zero_y_orientation(0,0) = slave2_zero(0,1);
                slave2_zero_y_orientation(1,0) = slave2_zero(1,1);
                slave2_zero_y_orientation(2,0) = slave2_zero(2,1);

                slave2_zero_z_orientation(0,0) = slave2_zero(0,2);
                slave2_zero_z_orientation(1,0) = slave2_zero(1,2);
                slave2_zero_z_orientation(2,0) = slave2_zero(2,2);

                Eigen::Matrix<double,3,1> rotation_axis2 = slave2_zero_z_orientation.cross(desired_z_orientation2);
                temp = sqrt(rotation_axis2(0,0)*rotation_axis2(0,0)
                           +rotation_axis2(1,0)*rotation_axis2(1,0)
                           +rotation_axis2(2,0)*rotation_axis2(2,0));
                rotation_axis2(0,0) = rotation_axis2(0,0) / temp;
                rotation_axis2(1,0) = rotation_axis2(1,0) / temp;
                rotation_axis2(2,0) = rotation_axis2(2,0) / temp;
                double rotation_angle2 = acos(slave2_zero_z_orientation.dot(desired_z_orientation2));
				std::cout<<"rotation_angle2: "<<rotation_angle2<<std::endl;

                Eigen::AngleAxisd V2(rotation_angle2, Eigen::Vector3d(rotation_axis2(0,0),rotation_axis2(1,0),rotation_axis2(2,0)));
                Eigen::Matrix<double,3,3> rotation_matrix2 = V2.toRotationMatrix();
				std::cout<<"rotation_matrix2"<<std::endl<<rotation_matrix2<<std::endl;

                desired_y_orientation2 = rotation_matrix2 * slave2_zero_y_orientation;
                desired_x_orientation2 = rotation_matrix2 * slave2_zero_x_orientation;

				std::cout<<"slave2_zero:"<<std::endl;
				std::cout<<slave2_zero<<std::endl;
				std::cout<<desired_x_orientation2<<std::endl;
				std::cout<<desired_y_orientation2<<std::endl;
				std::cout<<desired_z_orientation2<<std::endl;

                F_dest2.M(0,0) = desired_x_orientation2(0,0);
                F_dest2.M(0,1) = desired_y_orientation2(0,0);
                F_dest2.M(0,2) = desired_z_orientation2(0,0);

                F_dest2.M(1,0) = desired_x_orientation2(1,0);
                F_dest2.M(1,1) = desired_y_orientation2(1,0);
                F_dest2.M(1,2) = desired_z_orientation2(1,0);

                F_dest2.M(2,0) = desired_x_orientation2(2,0);
                F_dest2.M(2,1) = desired_y_orientation2(2,0);
                F_dest2.M(2,2) = desired_z_orientation2(2,0);

                F_dest2.p(0) = slave2_desire_pose(0,3);
                F_dest2.p(1) = slave2_desire_pose(1,3);
                F_dest2.p(2) = slave2_desire_pose(2,3);
                result2 = tracik_solver2.CartToJnt(q_init2,F_dest2,jointpositions_to_solve2);

            }else{
                for(int i=0;i<7;i++){
                    jointpositions_to_solve1(i) = joint_positions1[i];
					jointpositions_to_solve2(i) = joint_positions2[i];
                }
            }

            double joint_distance1 = 0;
			double joint_distance2 = 0;
             for(int i=0;i<7;i++){
                 joint_distance1 += pow((jointpositions_to_solve1(i)-joint_positions1[i]),2);
				 joint_distance2 += pow((jointpositions_to_solve2(i)-joint_positions2[i]),2);
			 }
             joint_distance1 = sqrt(joint_distance1);
			 joint_distance2 = sqrt(joint_distance2);
             std::cout<<"joint_distance1: "<<joint_distance1<<std::endl;
             std::cout<<"joint_distance2: "<<joint_distance2<<std::endl;
             if(joint_distance1<0.1 && joint_distance2<0.1){
                 if(!sim){
                     franka_msgs::servoj msg;
                     msg.keepalive = 1;
                     msg.cmd_q.resize(14);
                     for(unsigned int i=0;i<7;i++)
                         msg.cmd_q[i] = jointpositions_to_solve1(i);
                     for(unsigned int i=0;i<7;i++)
                         msg.cmd_q[i+7] = jointpositions_to_solve2(i);

                     pub_franka_script.publish(msg);
                 }else{
                     franka_msgs::servoj msg;
                     msg.cmd_q.resize(14);
                     for(unsigned int i=0;i<7;i++)
                         msg.cmd_q[i] = jointpositions_to_solve1(i);
                     for(unsigned int i=0;i<7;i++)
                         msg.cmd_q[i+7] = jointpositions_to_solve2(i);

                     pub_sim_servoj.publish(msg);
                 }
             }else{
                 if(!sim){
                     franka_msgs::servoj msg;
                     msg.keepalive = 0;
                     pub_franka_script.publish(msg);
                 }
             }
        }else{
            if(!sim){
                franka_msgs::servoj msg;
                msg.keepalive = 0;
                pub_franka_script.publish(msg);
            }
        }

        loop_rate.sleep();
    }
    std::cout<<"exit control thread"<<std::endl;
}

void franka_teleoperation::joint_position_callback(const sensor_msgs::JointState::ConstPtr& msg){
    for(unsigned int i=0;i<7;i++){
        joint_positions1[i] = msg->position[i];
    }
    for(unsigned int i=0;i<7;i++){
        joint_positions2[i] = msg->position[i+7];
    }
}

void franka_teleoperation::touch_map_callback(const robot_msgs::omega::ConstPtr& msg){
    for(unsigned int i=0;i<3;i++)
        master1_pos[i] = msg->data[i];
    for(unsigned int i=0;i<3;i++)
        master1_rpy[i] = msg->data[i+3];

    for(unsigned int i=0;i<3;i++)
        master2_pos[i] = msg->data[i+6];
    for(unsigned int i=0;i<3;i++)
        master2_rpy[i] = msg->data[i+9];
}
