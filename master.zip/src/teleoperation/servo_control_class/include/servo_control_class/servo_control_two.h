#ifndef SERVO_CONTROL_H__
#define SERVO_CONTROL_H__

#include <iostream>
#include <math.h>
#include <thread>
#include <termios.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

#include <linux/input.h> //for input_event
#include <fcntl.h> //for open()
#include <unistd.h> //for read() & close()

#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
#include <eigen3/Eigen/Geometry>

#include <ros/ros.h>
#include <robot_msgs/omega.h>
#include <franka_msgs/servoj.h>
#include <trac_ik/trac_ik.hpp>
#include <sensor_msgs/JointState.h>

#include <kdl/chain.hpp>
#include <kdl/tree.hpp>
#include <kdl/chainfksolver.hpp>
#include <kdl/chainfksolverpos_recursive.hpp>
#include <kdl/frames_io.hpp>
#include <kdl_parser/kdl_parser.hpp>
#include <kdl/chainiksolver.hpp>
#include <kdl/chainiksolvervel_pinv.hpp>
#include <kdl/chainiksolverpos_nr.hpp>
#include <kdl/chainjnttojacsolver.hpp>
#include <kdl/jacobian.hpp>
#include <kdl/chainiksolverpos_nr_jl.hpp>


class franka_teleoperation{
public:
    franka_teleoperation();
    ~franka_teleoperation();

    void halt();

private:
    ros::NodeHandle nh_;
    unsigned int nj1;
    unsigned int nj2;
    bool sim=true;
    bool filter = false;
    bool control_activate_ = false;
    bool eye_hand_cooperation = false;
    bool rcm_enable = false;
    std::string chain_start1, chain_end1, urdf_param, urdf_file;
    std::string chain_start2, chain_end2;
    ros::Publisher pub_franka_script;
    ros::Publisher pub_sim_servoj;
    ros::Subscriber sub_joint_position;
    ros::Subscriber sub_touch_map;

    std::thread* fk_thread_;
    std::thread* keyboard_thread_;
    std::thread* footswitch_thread_;
    std::thread* control_thread_;

    std::string keyBoard;
    std::string footswitch;
    double joint_positions1[7];
    double joint_positions2[7];
    double master1_pos[3];
    double master1_pos_zero[3];
    double master1_rpy[3];
    double master1_rpy_zero[3];
    double master2_pos[3];
    double master2_pos_zero[3];
    double master2_rpy[3];
    double master2_rpy_zero[3];

    int mode = 0;
    double direction1_x = 1;
    double direction1_y = 1;
    double direction1_z = 1;

    double direction1_rpy_r = -1;
    double direction1_rpy_p = -1;
    double direction1_rpy_y = 1;

    double direction2_x = 1;
    double direction2_y = 1;
    double direction2_z = 1;

    double direction2_rpy_r = -1;
    double direction2_rpy_p = -1;
    double direction2_rpy_y = 1;

    double scale_p_x=0.3;
    double scale_p_y=0.3;
    double scale_p_z=0.3;
    double scale_p_step = 0.02;
    double scale_p_max = 0.4;
    double scale_p_min = 0.02;

    double scale_r_x=0.04;
    double scale_r_y=0.04;
    double scale_r_z=0.04;
    double scale_r_step = 0.02;
    double scale_r_max = 0.1;
    double scale_r_min = 0.02;

    double tool_move = 0;
    double tool_step = 0.00003;

    double rcm_point1[3];
	double rcm_point2[3];

    double camera_in_base1[7];//x,y,z,qx,qy,qz,qw
    double camera_in_base2[7];//x,y,z,qx,qy,qz,qw
    Eigen::Matrix<double,4,4> camera_in_base1_matrix;
    Eigen::Matrix<double,4,4> camera_in_base2_matrix;

    Eigen::Matrix<double,4,4> cur_ee1;
    Eigen::Matrix<double,4,4> cur_ee2;

    Eigen::Matrix<double,4,4> slave1_zero;
    Eigen::Matrix<double,4,4> slave1_current_pose;
    Eigen::Matrix<double,4,4> slave1_zero_in_cam;

    Eigen::Matrix<double,4,4> slave2_zero;
    Eigen::Matrix<double,4,4> slave2_current_pose;
    Eigen::Matrix<double,4,4> slave2_zero_in_cam;


    void joint_position_callback(const sensor_msgs::JointState::ConstPtr& msg);
    void touch_map_callback(const robot_msgs::omega::ConstPtr& msg);
    void fk_func();
    void keyboard_func();
    void footswitch_func();
    void control_func();
};

#endif
