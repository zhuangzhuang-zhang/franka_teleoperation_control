#ifndef CANOPEN_H
#define CANOPEN_H
#include "controlcan/canopen/SDO.h"

#define CANOPEN_BROADCAST_ID 0x00

#endif
