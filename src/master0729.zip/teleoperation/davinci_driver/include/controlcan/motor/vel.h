#ifndef VEL_H
#define VEL_H

#include <stdint.h>

int vel_set_speed(int32_t vel);

#endif // VEL_H
