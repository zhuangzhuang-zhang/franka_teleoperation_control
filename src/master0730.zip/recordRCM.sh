#!/bin/bash

# echo "smj"|sudo -S /home/smj/c++test/build/m_test11

#source /opt/ros/kinetic/setup.bash
#roscore


source /home/master/franka_final_ws/devel/setup.bash
rosrun record_rcm record_rcm&
