#!/bin/bash

# echo "smj"|sudo -S /home/smj/c++test/build/m_test11

#source /opt/ros/kinetic/setup.bash
#roscore


python /home/master/franka_final_ws/src/terminate.py&
